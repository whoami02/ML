Changelog
=========

v0.7.0 (2024-09-09)
-------------------
Release note: `v0.7.0 <https://github.com/mindee/doctr/releases/tag/v0.7.0>`_

v0.6.0 (2022-09-29)
-------------------
Release note: `v0.6.0 <https://github.com/mindee/doctr/releases/tag/v0.6.0>`_

v0.5.1 (2022-03-22)
-------------------
Release note: `v0.5.1 <https://github.com/mindee/doctr/releases/tag/v0.5.1>`_

v0.5.0 (2021-12-31)
-------------------
Release note: `v0.5.0 <https://github.com/mindee/doctr/releases/tag/v0.5.0>`_

v0.4.1 (2021-11-22)
-------------------
Release note: `v0.4.1 <https://github.com/mindee/doctr/releases/tag/v0.4.1>`_

v0.4.0 (2021-10-01)
-------------------
Release note: `v0.4.0 <https://github.com/mindee/doctr/releases/tag/v0.4.0>`_

v0.3.1 (2021-08-27)
-------------------
Release note: `v0.3.1 <https://github.com/mindee/doctr/releases/tag/v0.3.1>`_

v0.3.0 (2021-07-02)
-------------------
Release note: `v0.3.0 <https://github.com/mindee/doctr/releases/tag/v0.3.0>`_

v0.2.1 (2021-05-28)
-------------------
Release note: `v0.2.1 <https://github.com/mindee/doctr/releases/tag/v0.2.1>`_

v0.2.0 (2021-05-11)
-------------------
Release note: `v0.2.0 <https://github.com/mindee/doctr/releases/tag/v0.2.0>`_

v0.1.1 (2021-03-18)
-------------------
Release note: `v0.1.1 <https://github.com/mindee/doctr/releases/tag/v0.1.1>`_

v0.1.0 (2021-03-05)
-------------------
Release note: `v0.1.0 <https://github.com/mindee/doctr/releases/tag/v0.1.0>`_
