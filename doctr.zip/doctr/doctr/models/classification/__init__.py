from .mobilenet import *
from .resnet import *
from .vgg import *
from .magc_resnet import *
from .vit import *
from .textnet import *
from .zoo import *
